let vardas='Adrijana';
let pavarde='Mazuronytė';
let amzius=19;
let ugis=1.68;
let svoris=58;
let mokykla='Sv. Ignaco Lojolos kolegija';
let grupe='OT-15';
let kursas='Sveikatos mokslai';
let pavadinimas='Ortopedijos technologija';
let kreditai=35;

console.log(vardas);
console.log(pavarde);
console.log(amzius);
console.log(ugis);
console.log(svoris);
console.log(mokykla);
console.log(grupe);
console.log(kursas);
console.log(pavadinimas);
console.log(kreditai);



let eilute='__________________________';
let pavadinimas1='Jieznas';
let valstybe='Lietuva';
let apskritis='Kauno apsk.';
let data=1492;
let meras='A.Bartusevicius';
let plotas='2.50 km²';
let gyventojai=1024;

console.log(eilute);
console.log(pavadinimas1);
console.log(valstybe);
console.log(apskritis);
console.log(data);
console.log(meras);
console.log(plotas);
console.log(gyventojai);



let manoVardas='Aistė';
let vidurkis=7.5;
let bet_kas='Bet';

console.log(eilute);
console.log(manoVardas);
console.log('grupe:',grupe);
console.log('vidurkis:',vidurkis);
console.log(bet_kas + bet_kas +''
            + bet_kas + bet_kas + bet_kas);



let grusis='Bichon Frise';
let gamzius='4 m.';
let gspalva='balta';
let gsvoris='5 kg.';

console.log(eilute);
console.log('Gyvunas -',grusis, '(',gamzius,'),','jo kailio spalva', gspalva, 'ir jis sveria', gsvoris);



let sym='^';

console.log(eilute);
console.log(sym + sym + sym + sym 
    +sym + sym + sym + sym + sym +'\n'
    + sym +'      ', sym+ '\n'
    + sym +'      ', sym +'\n'
    + sym +'      ', sym +'\n'
    +sym + sym + sym + sym 
    +sym + sym + sym + sym
    + sym);