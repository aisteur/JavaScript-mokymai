console.log('Aistė', '28m.\n Noriu pakeisti savo specializaciją');
console.log(' Su Nemunu \n Pateka saulė.\n Su Nemunu \n Leidžias toli. \n Prie Nemuno \n Mano pasaulis, \n Prie Nemuno \n Mano šalis.');
console.log('***\n* *\n***');
console.log('*\n**\n***');
console.log(' LDK Vyriausias raštininkas Antanas Mykolas Pacas mirė 1774 m., bet ir po jo mirties žmona Teresė darė didelę įtaką Jieznui.\n Antanas Mykolas Pacas savo valdymą Jiezne pradėjo 1747 m. balandžio 9 d.\n Apie tai byloja jo rašytas laiškas Pažaislio kamaldulių vienuolyno viršinnkui O. Ildefonsui.');
alert('Šis puslapis laukia lektoriaus įvertinimo');
console.log('+--------+--------+\nI Vardas I Amžius I\n+--------+--------+\nI Tomas  I 24     I\nI Jonas  I 26     I \nI Justė  I 25     I\n+--------+--------+');
