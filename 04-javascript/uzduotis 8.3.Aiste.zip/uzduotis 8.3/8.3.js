let a=2;
let b=3;
let c=4;
let d=5;
let eilute='------------------';

console.log(a);
console.log((a)*2);
console.log(a ** 3);


console.log(eilute);
console.log( a + b + c );
console.log(a*b*c);


console.log(eilute);
console.log(b+c);
console.log(c-a);
console.log((b+c)*(c-a));
console.log((b+c)/(c-a));
console.log((a+b+c+d)/4);


console.log(eilute);
console.log('4+5='+(c+d));
console.log('4-5='+(c-d));
console.log('4*5='+(c*d));
console.log('4/5='+(c/d));
console.log(-1+4*6);
console.log((35+5)%7);
console.log(14+-4*6/12);
console.log(2+15/6*1-7%2);


console.log(eilute);
console.log(7*1);
console.log(7*2);
console.log(7*3);
console.log(7*4);
console.log(7*5);
console.log(7*6);
console.log(7*7);
console.log(7*8);
console.log(7*9);
console.log(7*10);


let s=77;
console.log(eilute);
console.log(Math.floor(s/10));
console.log(s%10);
console.log((Math.floor(s/10))+(s%10));





